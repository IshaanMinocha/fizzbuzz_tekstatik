//baadme likhunga
// TODO : button click pe get endpoint, method
// crucial dep: needs to send atleast a request to get that so this better